from .bpe import get_encoder

__all__ = ['get_encoder']
