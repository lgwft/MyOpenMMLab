from animated_drawings import render

render.start('./configs/mvc/slamdunk.yaml')
