# MMagic代码实战教程

OpenMMLab主页：https://openmmlab.com

OpenXLab应用中心AIGC在线Demo：https://beta.openxlab.org.cn/apps

MMagic主页：https://github.com/open-mmlab/mmagic

视频讲解：同济子豪兄 https://space.bilibili.com/1900783

代码测试[云GPU环境](https://featurize.cn?s=d7ce99f842414bfcaea5662a97581bd1)：GPU RTX 3060、CUDA v11.2
